# Render.com Deployment

## Environment Variables for Render
Copy these exactly into Render's Environment Variables section:

```
NODE_ENV=production
PORT=10000
HOST=0.0.0.0
CLIENT_ID=ZLw7FjAEJ3h97ZcF2k2qG93tq2LDFsFM
CLIENT_SECRET=V6mpOxb7TFWQws2YKHE6GJyuA5j2RBYoamcoFGH36gdO
OM_MERCHANT_KEY=427ab675
OM_APPLICATION_ID=sdbSYSBaO2e2Dg60
BASE_URL=https://dreamexdatalab.com
CORS_ALLOWED_ORIGINS=https://dreamexdatalab.com
OM_CURRENCY=GNF
OM_TOKEN_URL=https://api.orange.com/oauth/v3/token
OM_INIT_URL=https://api.orange.com/orange-money-webpay/gn/v1/webpayment
OM_STATUS_URL=https://api.orange.com/orange-money-webpay/gn/v1/transactionstatus
OM_SEND_X_TOKEN=true
OM_AMOUNT_AS_NUMBER=true
WEBHOOK_SECRET=dreamex_orange_2025_secure_webhook_key
SUCCESS_URL=/success.html
CANCEL_URL=/cancel.html
```

## Deployment Settings
- **Name**: orange-money-api
- **Runtime**: Node
- **Build Command**: npm install
- **Start Command**: node server.js
- **Instance Type**: Free