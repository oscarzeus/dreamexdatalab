# Orange Money API - Complete Deployment Guide

## ✅ What's Ready
- ✅ Node.js server with Orange Money integration
- ✅ Environment variables configured  
- ✅ Production-ready configuration files
- ✅ Testing endpoints working locally

## 🎯 Quick Deploy Options

### Option 1: Render (Recommended - Free Tier)

1. Go to https://render.com → Sign up/login
2. Click "New +" → "Web Service"  
3. Connect your GitHub account or upload files
4. Set these settings:
   - **Name**: `orange-api`
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   
5. Add Environment Variables:
```
NODE_ENV=production
PORT=10000
CLIENT_ID=ZLw7FjAEJ3h97ZcF2k2qG93tq2LDFsFM
CLIENT_SECRET=V6mpOxb7TFWQws2YKHE6GJyuA5j2RBYoamcoFGH36gdO
OM_MERCHANT_KEY=427ab675
BASE_URL=https://dreamexdatalab.com
CORS_ALLOWED_ORIGINS=https://dreamexdatalab.com
OM_CURRENCY=GNF
```

6. Deploy → Get URL like: `https://orange-api.onrender.com`

### Option 2: Heroku

1. Go to https://heroku.com → Create app
2. Upload these files or connect GitHub:
   - `server.js`
   - `package.json`  
   - `Procfile` (already created)
   - `public/` folder
3. Set Config Vars (same as above)
4. Deploy

### Option 3: Vercel (Serverless)

1. Go to https://vercel.com
2. Upload files
3. Add `vercel.json`:
```json
{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/server.js"
    }
  ]
}
```

## 🌐 DNS Configuration (After Deployment)

Once you have your deployment URL (e.g., `https://orange-api.onrender.com`):

### Set up api.dreamexdatalab.com

1. **In your domain registrar** (where you bought dreamexdatalab.com):
   - Add CNAME record:
     - **Name**: `api`
     - **Value**: `orange-api.onrender.com` (without https://)
   
2. **In your deployment platform**:
   - Add custom domain: `api.dreamexdatalab.com`
   - Wait for SSL certificate (automatic)

### Alternative: Use the deployment URL directly

Update your registration form to use the deployment URL:
- Change API_BASE to: `https://orange-api.onrender.com`
- Test at: `https://orange-api.onrender.com/health`

## 🧪 Testing Your Deployment

1. **Health Check**: `https://your-domain/health`
2. **Config Check**: `https://your-domain/api/debug/config`  
3. **Payment Test**: Use your registration form

## 📁 Files to Deploy

Your `orange-api-server` folder contains everything needed:
- ✅ `server.js` (main app)
- ✅ `package.json` (dependencies)
- ✅ `Procfile` (Heroku start command)  
- ✅ `.env` (environment template)
- ✅ `public/` (success/cancel pages)

## 🚀 Next Steps

1. Choose a platform (Render recommended for simplicity)
2. Deploy the files  
3. Configure environment variables
4. Set up DNS (or use deployment URL directly)
5. Test payment flow

**Need help with a specific platform? Let me know which one you prefer!**